import React, { useState, useEffect, useCallback } from "react";
import {
  Send,
  Instagram,
  Facebook,
  Youtube,
  Music2,
  Globe,
  MessageCircle,
  Link2,
  Lock,
  Plus,
  Pencil,
  Trash2,
  X,
  Check,
  ArrowUpRight,
  ArrowRight,
  Users,
  BookOpen,
  Layers,
  Phone,
  ChevronDown,
  ChevronUp,
  PlayCircle,
  FileText,
  Clock,
} from "lucide-react";

const ADMIN_PASSWORD = "haedar077151haedar123";
const LOGO_SRC = "/images/logo.jpg";

const PLATFORM_META = {
  telegram: { label: "تليكرام", icon: Send, color: "#2F6F62" },
  instagram: { label: "انستقرام", icon: Instagram, color: "#C1502E" },
  whatsapp: { label: "واتساب", icon: MessageCircle, color: "#2F6F62" },
  facebook: { label: "فيسبوك", icon: Facebook, color: "#2F6F62" },
  youtube: { label: "يوتيوب", icon: Youtube, color: "#C1502E" },
  tiktok: { label: "تيك توك", icon: Music2, color: "#14181F" },
  website: { label: "موقع", icon: Globe, color: "#6B7280" },
  phone: { label: "اتصال", icon: Phone, color: "#2F6F62" },
  other: { label: "رابط", icon: Link2, color: "#6B7280" },
};

const WORKSHOP1_IMG = "/images/workshop1.jpg";

const SEED_WORKSHOPS = [
  {
    id: "w3",
    title: "جهاز تخطيط القلب ECG — الصيانة والتشخيص",
    category: "أجهزة طبية",
    description:
      "تعلن منصّة نبض عن إقامة ورشة تخصصية بعنوان: جهاز تخطيط القلب ECG.\n\n👨‍🔧 تقديم: المهندس مجتبى قحطان\nمهندس طب حياتي يمتلك خبرة تمتد لأكثر من 6 سنوات في مجال هندسة الأجهزة الطبية، حاصل على عدد من الشهادات والدورات التخصصية، ويمتلك خبرة علمية وعملية في مجال الأجهزة الطبية وتشغيلها وصيانتها.\n\n🔬 محاور الورشة:\n▪️ مقدمة عن جهاز ECG واستخداماته وأهميته.\n▪️ مبدأ عمل جهاز تخطيط القلب.\n▪️ التركيب الداخلي والخارجي للجهاز.\n▪️ مسار الإشارة من الأقطاب إلى العرض والطباعة.\n▪️ الصيانة الوقائية (PM) والمعايرة.\n▪️ الأعطال الشائعة وطرق تشخيصها.\n▪️ أشهر رسائل الأعطال وكيفية التعامل معها.\n▪️ تدريب عملي على فحص الجهاز وتشخيص وصيانة الأعطال.\n\n✨ ورشة تجمع بين الجانب العلمي والتطبيق العملي في مجال الأجهزة الطبية.\n\n📌 كونوا على الموعد.\n\nPULSE | Biomedical Engineering 🩺🔬",
    imageUrl: "/images/workshop3.jpg",
    date: "28 / 8 / 2026 — الساعة 9:00 مساءً",
    place: "أونلاين (عبر تليكرام)",
    link: "https://t.me/+UTXYdsBvEKZiY2Vi",
    platform: "telegram",
    status: "active",
  },
  {
    id: "w2",
    title: "ورشة تخصصية | الهندسة العصبية (Neural Engineering)",
    category: "هندسة عصبية",
    description:
      "تعلن منصة نبض هندسة الطب الحياتي عن إقامة ورشة تخصصية في الهندسة العصبية، أحد الفروع المهمة والحديثة في هندسة الطب الحياتي، والتي تجمع بين الهندسة والعلوم العصبية بهدف فهم الجهاز العصبي وتطوير تقنيات وأجهزة تساعد في تشخيص وعلاج الاضطرابات العصبية والتفاعل مع الإشارات العصبية.\n\n🔬 شنو هي الهندسة العصبية؟\nالهندسة العصبية هي مجال متعدد التخصصات يهتم بدراسة الإشارات والأنظمة العصبية وتوظيف المبادئ الهندسية لتطوير حلول وتقنيات طبية، مثل واجهات الدماغ والحاسوب، تحليل الإشارات العصبية، الأطراف والأجهزة العصبية الذكية، وغيرها من التطبيقات الطبية الحديثة.\n\n📚 محاور الورشة\n🔹 مقدمة في الهندسة العصبية.\n🔹 أساسيات الجهاز العصبي وآلية نقل الإشارات العصبية.\n🔹 واجهات الدماغ والحاسوب (BCI).\n🔹 الأجهزة والتقنيات المستخدمة في هندسة الأعصاب.\n🔹 معالجة وتحليل الإشارات العصبية.\n🔹 تطبيقات الهندسة العصبية في المجال الطبي.\n🔹 الذكاء الاصطناعي في هندسة الأعصاب.\n🔹 فرص العمل والمسار المهني.\n🔹 مستقبل الهندسة العصبية.\n🔹 دراسة حالة (Case Study) وتطبيق عملي.\n\n👩‍🏫 نبذة عن المدربة\nالمهندسة زهراء مخلص\nتمتلك خبرة في مجال هندسة الطب الحياتي لأكثر من 5 سنوات، ومدربة متخصصة في تقديم المحتوى العلمي والتعليمي. كما تعمل صانعة محتوى علمي في منصة نبض هندسة الطب الحياتي، وتهتم بتبسيط المفاهيم العلمية ونشر المعرفة في مختلف تخصصات هندسة الطب الحياتي. وتختص باهتمامها في مجالي الهندسة العصبية والهندسة الوراثية، وتسعى إلى تقديم المعرفة العلمية بأسلوب عملي ومبسط لطلبة ومهتمي التخصص.\n\n🧠 إذا كنت مهتمًا بالدماغ، الإشارات العصبية، الذكاء الاصطناعي والتقنيات الطبية المستقبلية… فهذه الورشة إلك.\n\nمنصة نبض هندسة الطب الحياتي\nنحو معرفة أعمق… ومستقبل هندسي أقوى. 🧠🔬",
    imageUrl: "/images/workshop2.jpg",
    date: "20 / 8 / 2026 — الساعة 9:00 مساءً",
    place: "أونلاين (عبر تليكرام)",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w1",
    title: "دورة مجانية في مجال الأجهزة الطبية",
    category: "أجهزة طبية",
    description:
      "يسر منصة نبض هندسة الطب الحياتي الإعلان عن إقامة دورة مجانية في مجال الأجهزة الطبية، بإشراف وتدريب المهندس حيدر علي.\n\nمحاور الدورة:\n- جهاز المونيتور (Patient Monitor): آلية العمل، تشخيص الأعطال، والصيانة.\n- جهاز التنفس الصناعي (Ventilator): آلية العمل، تشخيص الأعطال، والصيانة.\n- التعرف على أقسام المستشفى ووظائفها.\n\nتفاصيل الدورة:\n💻 إلكترونية (عن بُعد)\n💰 مجانية بالكامل\n⏳ مدة الدورة: 6 أسابيع\n🎥 محاضرة أسبوعيًا أو محاضرتان حسب الجدول\n📝 اختبار بعد كل محاضرة لقياس مستوى الاستيعاب",
    imageUrl: WORKSHOP1_IMG,
    date: "موعد انطلاق الدورة: 15 / 7 / 2026",
    place: "أونلاين (عن بُعد)",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w4",
    title: "ورشة أساسيات المختبر الطبية | جانب عملي + جانب نظري",
    category: "مختبرات طبية",
    description: "هل ترغب بتطوير مهاراتك ودخول عالم المختبرات الطبية بثقة وكفاءة؟\n\nبالتعاون المشترك منصة شاهد & منصة نبض عن إقامة ورشة تدريبية متخصصة في أساسيات المختبر الطبية تجمع بين الجانب العملي والنظري ومناسبة للطلاب والخريجين وكل من يرغب بتطوير مهاراته في المجال المختبري.\n\n⏱ مدة الورشة: 3 ساعات\n🎓 شهادة مشاركة: اختيارية\n\n⚠️ عدد المقاعد محدود",
    imageUrl: "/images/w_lab.jpg",
    date: "السبت 15/8 — الساعة 10:00 صباحًا",
    place: "الكاظمية – مكتبة الكاظمية العامة",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w5",
    title: "حاضنة الأطفال (Infant Incubator)",
    category: "أجهزة طبية",
    description: "تحت إشراف وزارة الشباب والرياضة / المركز الوطني للعمل التطوعي\nإيمانًا بأهمية التطوير المستمر ورفد الكوادر الهندسية والطبية بالمهارات العملية والتقنية اللازمة للتميز في سوق العمل، وتجسيدًا لشعارنا الدائم في الانتقال من الجانب النظري إلى التطبيق العملي؛\n\n🔷 نعلن وبالتعاون منصة نبض هندسة الطب الحياتي، مع رابطة رواد هندسة الطب الحياتي، عن إقامة ورشة عمل علمية تخصصية (مجانية)\n\n🔹 بعنوان: حاضنة الأطفال (Infant Incubator)\nتستهدف هذه الورشة المهندسين، وطلبة كليات الهندسة (الطب الحياتي والأجهزة الطبية)، وكافة المهتمين والناشطين في القطاع والمجال الطبي التخصصي لتعزيز مهاراتهم التقنية في صيانة ومبدأ عمل هذا الجهاز الحيوي.\n\n🔹 تُقدم الورشة: المهندسة سارة محمد\n• بكالوريوس هندسة الأجهزة الطبية.\n• دبلوم في الإدارة الصحية والطبية.\n• حاصلة على شهادة تخصصية من جمهورية مصر العربية في مجال أجهزة السونار.\n• تمتلك أكثر من (20) شهادة معتمدة في مختلف مجالات الأجهزة الطبية.\n• عضو نقابة المهندسين وعضو نقابة الإداريين.\n• مهندسة ممارسة في مستشفى اليرموك التعليمي.\n\n🔹 محاور الورشة الرئيسية:\n1- التعريف الشامل بحاضنة الأطفال وأهميتها الحيوية في رعاية حديثي الولادة (الخدج).\n2- مبدأ عمل الحاضنة وآلية المحافظة على البيئة الحيوية المناسبة للرضيع.\n3- المكونات الأساسية للحاضنة (الهيكلية والإلكترونية) ووظيفة كل جزء منها.\n4- أنظمة التحكم الذكية داخل الحاضنة (أنظمة الحرارة، الرطوبة، الأوكسجين، ومنظومات الإنذار).\n5- الأعطال الشائعة، آلية الفحص الفني، وأساسيات الصيانة الوقائية (Preventive Maintenance).\n6- بروتوكولات تعقيم حاضنة الأطفال، طرق التنظيف الصحيحة، وإجراءات مكافحة العدوى لسلامة الأطفال.",
    imageUrl: "/images/w_incubator.jpg",
    date: "الخميس 2026/7/9 — الساعة 10:00 صباحًا",
    place: "بغداد - الكرادة - تقاطع المسبح - وزارة الشباب والرياضة / مكتب الوزير / المركز الوطني للعمل التطوعي",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w6",
    title: "الإسعافات الأولية (First Aid)",
    category: "إسعافات أولية",
    description: "تُعلن منصة نبض هندسة الطب الحياتي بالتعاون مع منصة شاهد التعليمية عن إقامة ورشة علمية مجانية بعنوان:\n🚑 الإسعافات الأولية (First Aid)\n\nهل تمتلك المهارات اللازمة للتعامل مع الحالات الطارئة وإنقاذ حياة شخص قبل وصول المساعدة الطبية؟\n\nانضموا إلينا في ورشة تدريبية تجمع بين الجانب النظري والتطبيق العملي لتعلم أهم أساسيات الإسعافات الأولية بطريقة مبسطة واحترافية.\n\n💰 الورشة مجانية بالكامل\n\nمحاور الورشة:\n✅ أساسيات الإسعافات الأولية\n✅ التعامل مع الحالات الطارئة\n✅ إيقاف النزيف والكسور\n✅ الإنعاش القلبي الرئوي (CPR)\n\n🎓 مميزات الورشة:\nتدريب عملي وتطبيقات واقعية.\nحالات محاكاة لرفع المهارات.\nشهادة مشاركة للحضور.\nمناسبة لطلبة وخريجي التخصصات الطبية والهندسية وجميع المهتمين.\n\n✨ كن سببًا في إنقاذ حياة، فالمعرفة والمهارة قد تصنعان الفرق في اللحظات الحرجة.",
    imageUrl: "/images/w_firstaid.jpg",
    date: "السبت 6/20 — الساعة 12:00 ظهرًا",
    place: "الكاظمية – شارع 60 (قرب مستشفى الكاظمية التعليمي)",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w7",
    title: "ورشة الأجهزة الطبية في العمل التطوعي وخدمة المجتمع",
    category: "أجهزة طبية",
    description: "من قلب الميدان.. نصنع الأثر الهندسي\n\nتعلن رابطة \"رواد هندسة الطب الحياتي\" بالتعاون مع منصة نبض هندسة الطب الحياتي، وبإشراف وزارة الشباب والرياضة / المركز الوطني للعمل التطوعي، عن إطلاق ورشتها التخصصية النوعية التي تدمج بين المهارة الهندسية والمسؤولية المجتمعية.\n\n🔹 عنوان الورشة: \"الأجهزة الطبية في العمل التطوعي وخدمة المجتمع\"\nتعد هذه الورشة بوابة تعليمية وعملية تهدف إلى تمكين مهندسي المستقبل من الأدوات التقنية اللازمة للمساهمة الفاعلة في صيانة وتشغيل الأجهزة الحيوية التي تخدم المجتمع.\n\n🔹 محاور الورشة:\n1- جهاز قياس الضغط الزئبقي (Mercury Sphygmomanometer): آلية العمل، القراءة الدقيقة، وإجراءات الصيانة الدورية لضمان الجودة.\n2- جهاز بخاخ التنفس الطبي (Nebulizer): مبادئ تحويل الدواء إلى رذاذ، طرق الاستخدام الصحيحة، وبروتوكولات التعقيم والصيانة الوقائية.\n3- جهاز تحفيز العضلات (EMS): الآلية الكهربائية للتحفيز، الإعدادات العلاجية، مع التركيز على تعليمات السلامة وتشخيص الأعطال.\n4- جهاز غسيل الكلى (Hemodialysis Machine): جولة في المكونات الأساسية للجهاز، آلية عمل الغشاء شبه النافذ، وأنظمة التحكم وضمان سلامة المرضى.",
    imageUrl: "/images/w_devices_ali_sara.jpg",
    date: "الجمعة 2026/4/17 — الساعة 11:00 صباحًا",
    place: "بغداد - الكرادة - تقاطع المسبح - وزارة الشباب والرياضة / مكتب الوزير / المركز الوطني للعمل التطوعي",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
  {
    id: "w8",
    title: "دورة العلاج الطبيعي والتأهيل النفسي لتركيب الأطراف الصناعية",
    category: "علاج طبيعي",
    description: "بِسم الله الرحمن الرحيم\n\nيُعلِنونَ لَكم مُشرِفو منصة نَبض بدورة علمية تخص العلاج الطبيعي وتأهيل النفسي لتركيب الأطراف الصناعية بالتعاون مع مجمع الرسول الأعظم التأهيلي التابع للحشد الشعبي\n\nملاحظة: الدورة مجانية\nملاحظة: بعد اكمال الدورة سيتم توزيع شهادات مشاركة للمُشاركين في الدورة وأيضًا مجانية\n\nالمنظمون لِـهذا العمل:\nالمهندس الطبي: حَـيدر علي\nالمهندس الطبي: علي عدي",
    imageUrl: "/images/w_rehab.jpg",
    date: "سنحدد الموعد قريبًا جدًا",
    place: "بغداد - الأعظمية",
    link: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
    status: "ended",
  },
];

const SEED_SOCIAL = [
  {
    id: "s1",
    title: "حسابنا على انستقرام",
    url: "https://www.instagram.com/b.m.e_pulse?igsi=MTF3ejJhMWZnN2NhbQ==",
    platform: "instagram",
  },
  {
    id: "s2",
    title: "حسابنا على تليكرام",
    url: "https://t.me/+-Mk0HGO4f_FhNGQy",
    platform: "telegram",
  },
  {
    id: "s3",
    title: "م. علي عدي — رئيس منصة نَبض",
    url: "tel:+9647731255527",
    platform: "phone",
  },
  {
    id: "s4",
    title: "م. حَيدر علي — المدير الإداري",
    url: "tel:+9647729937388",
    platform: "phone",
  },
];

const SEED_CONTENT = [
  {
    id: "series1",
    type: "series",
    title: "سلسلة دروس #يلا_نفهم",
    lessons: [
      {
        id: "l1",
        title: "الدرس الأول",
        url: "https://www.instagram.com/p/DbsfQiajoey/?igsi=Nm15em5wOGlzcDIy",
      },
      {
        id: "l2",
        title: "الدرس الثاني",
        url: "https://www.instagram.com/p/DcBpw5RCj_Y/?igsi=MXdydWl6M3dtOWE5cg==",
      },
      {
        id: "l3",
        title: "الدرس الثالث",
        url: "https://www.instagram.com/p/DcePYBlDjoH/?igsi=MWM5MnVuemNvMnNxcw==",
      },
    ],
  },
  {
    id: "series2",
    type: "series",
    title: "الدورة الصيفية لصيانة الأجهزة الطبية",
    lessons: [
      {
        id: "s2-1",
        title: "أقسام المستشفيات",
        url: "https://youtu.be/X_-JxtcsxQU?si=ymnuWsL4oKbH31im",
      },
      {
        id: "s2-2",
        title: "جهاز الفنتليتر",
        children: [
          {
            id: "s2-2-1",
            title: "الجزء الأول",
            url: "https://youtu.be/_90keF4t3rU?si=rKyVQLt8DwZcXN70",
          },
          {
            id: "s2-2-2",
            title: "الجزء الثاني",
            url: "https://youtu.be/JaGgr0e7Pt8?si=prSPeIOuaVFxwtzL",
          },
        ],
      },
      {
        id: "s2-3",
        title: "جهاز المونيتور",
        children: [
          {
            id: "s2-3-1",
            title: "الجزء الأول",
            url: "https://youtu.be/BemyAc8zv38?si=5IQ2Aq2pJvOq6Y6v",
          },
          {
            id: "s2-3-2",
            title: "الجزء الثاني",
            url: "https://youtu.be/kYPrb2GaweE?si=2Nt4hpGxztFMnRaG",
          },
        ],
      },
    ],
  },
  {
    id: "series3-films",
    type: "series",
    title: "أفلامنا العلمية",
    lessons: [
      {
        id: "film1",
        title: "فيلم مشروع القبعة الذكية للمكفوفين",
        url: "https://www.instagram.com/reel/DX7Dk1SNoId/?igsi=MmRuazZyYjUwM2Ny",
      },
      {
        id: "film2",
        title: "فيلم مريض التوحد وعلاجه بجهاز الECT",
        children: [
          {
            id: "film2-1",
            title: "جزء اول",
            url: "https://www.instagram.com/reel/Db3XA2xtAP_/?igsi=MW5yeWRiYnY4ZXI1Yw==",
          },
          {
            id: "film2-2",
            title: "جزء ثاني",
            pendingLabel: "سيُضاف يوم الخميس",
          },
        ],
      },
    ],
  },
  {
    id: "series4-heroes",
    type: "series",
    title: "محتوى أبطال منصة نبض",
    lessons: [
      {
        id: "hero-ali",
        title: "محتوى م.علي عدي",
        children: [
          {
            id: "hero-ali-bio",
            title: "نبذة عن مهندس علي عدي",
            note: "",
          },
          {
            id: "hero-ali-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DUTkoMPjVep/?igsi=ZWw3M3VqZ21nNXVv",
          },
          {
            id: "hero-ali-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DUtZ1eGDVKj/?igsi=MTBrdTdxb3Zvb3I1Mg==",
          },
          {
            id: "hero-ali-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DT3NR9qDQ4E/?igsi=MWRuM3Ywbm4yd3J5cg==",
          },
          {
            id: "hero-ali-4",
            title: "المحتوى الرابع",
            url: "https://www.instagram.com/reel/DVMRx8JDXPs/?igsi=MW52NWkzcDVhNDVheg==",
          },
          {
            id: "hero-ali-5",
            title: "المحتوى الخامس",
            url: "https://www.instagram.com/reel/DU6jdndDU30/?igsi=MWh6dXZndDBrdngydw==",
          },
          {
            id: "hero-ali-6",
            title: "المحتوى السادس",
            url: "https://www.instagram.com/reel/DVi6PF9DRBu/?igsi=MTV1Yjh2MjQza3Jwcg==",
          },
          {
            id: "hero-ali-7",
            title: "المحتوى السابع",
            url: "https://www.instagram.com/reel/DWwfmMFDWid/?igsi=YjJkNjY3bnhub3Ny",
          },
        ],
      },
      {
        id: "hero-haidar",
        title: "محتوى م.حَيدر علي",
        children: [
          {
            id: "hero-haidar-bio",
            title: "نبذة عن مهندس حَيدر علي",
            note: "حَيدر علي مهندس طب حياتي تاريخ الولادة 2004/7/20\nلاعب منتخب وطني لرياضة الملاكمة وايضا عازف لآلة الكلارينيت\nله العديد من الانجازات ومنها حاصل على شهادة علم النفس السريري والبايولوجي\nوحاصل على شهادة ISPO للأطراف الصناعية\nوهو ممثل في قسمه ويمثل جامعته وقسمه وأيضًا أستاذ تدريسي يشرح المواد العلمية والمحاضرات التي تخص الأطراف والأجهزة الطبية\nومركزه في منصة نبض: مساعد إداري.",
          },
          {
            id: "hero-haidar-account",
            title: "حساب م.حَيدر علي",
            url: "https://www.instagram.com/0je4?igsi=dHphNmJhdXRyYjNv",
          },
          {
            id: "hero-haidar-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DUL3HJYjVnp/?igsi=MW02bjMwZnA1dms2eA==",
          },
          {
            id: "hero-haidar-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DUln6rKDX89/?igsi=MXY5cmdodjh1bHVucg==",
          },
          {
            id: "hero-haidar-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DVCB9lAjVGR/?igsi=eXYzamF5NzBwbGJw",
          },
          {
            id: "hero-haidar-4",
            title: "المحتوى الرابع",
            url: "https://www.instagram.com/reel/DV3y4bGDZPT/?igsi=MWJpZmZsaTUyMHV0Zg==",
          },
          {
            id: "hero-haidar-5",
            title: "المحتوى الخامس",
            url: "https://www.instagram.com/reel/DW9TkZsjcH2/?igsi=bnB2OTEzcnFhZ2c0",
          },
          {
            id: "hero-haidar-6",
            title: "المحتوى السادس",
            url: "https://www.instagram.com/reel/DVeF_hvjY1x/?igsi=MWN3NnB6d2t2ZHVudg==",
          },
          {
            id: "hero-haidar-7",
            title: "المحتوى السابع",
            url: "https://www.instagram.com/reel/DWUDSWTjXTc/?igsi=Y2N1bDRieWRrY2Uw",
          },
          {
            id: "hero-haidar-8",
            title: "المحتوى الثامن",
            url: "https://www.instagram.com/reel/DYH67SEtiD9/?igsi=dTBtYWJ3bG0xM21j",
          },
          {
            id: "hero-haidar-9",
            title: "المحتوى التاسع",
            url: "https://www.instagram.com/s/aGlnaGxpZ2h0OjE4MDYzNjYzODAwNTA2NDUx?story_media_id=3957680388734614717_512027207&igsi=bDNxNDc1cXZlNWZk",
          },
        ],
      },
      {
        id: "hero-zaid",
        title: "محتوى م.زيد عبد السلام",
        children: [
          {
            id: "hero-zaid-bio",
            title: "نبذة عن مهندس زيد عبد السلام",
            note: "",
          },
          {
            id: "hero-zaid-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DV9F4HkjVkB/?igsi=MW0xMWE0NmE1cnV6bQ==",
          },
          {
            id: "hero-zaid-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DVOUhZMDdwZ/?igsi=d3N2NmJkOXZzN3hl",
          },
          {
            id: "hero-zaid-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DU8-XqWDf0z/?igsi=MWFlcGU4ZG9mMThheg==",
          },
          {
            id: "hero-zaid-4",
            title: "المحتوى الرابع",
            url: "https://www.instagram.com/reel/DX7Dk1SNoId/?igsi=MTNybHNldmg4MDE2OQ==",
          },
        ],
      },
      {
        id: "hero-mujtaba",
        title: "محتوى م.مجتبى قحطان",
        children: [
          {
            id: "hero-mujtaba-bio",
            title: "نبذة عن مهندس مجتبى قحطان",
            note: "",
          },
          {
            id: "hero-mujtaba-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DUEH1PGDX5K/?igsi=MWllZHA1aHRsaXY3cg==",
          },
          {
            id: "hero-mujtaba-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DYhsbyrtMDT/?igsi=MWMwY2w2amp3MGE5ZA==",
          },
          {
            id: "hero-mujtaba-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DUTkoMPjVep/?igsi=MTJub3Nla2w3anFqMw==",
          },
          {
            id: "hero-mujtaba-4",
            title: "المحتوى الرابع",
            url: "https://www.instagram.com/reel/DUbYanwDbCS/?igsi=bDVoeDlxbG15bm9n",
          },
          {
            id: "hero-mujtaba-5",
            title: "المحتوى الخامس",
            url: "https://www.instagram.com/reel/DVZJXQLjcWL/?igsi=aHNzM29mdnpzOTN2",
          },
          {
            id: "hero-mujtaba-6",
            title: "المحتوى السادس",
            url: "https://www.instagram.com/reel/DU3WTKtDft2/?igsi=NHN1MWNvd2xhcGhs",
          },
          {
            id: "hero-mujtaba-7",
            title: "المحتوى السابع",
            url: "https://www.instagram.com/reel/DV0-QxqjSN1/?igsi=MXc2bmFlczh0M2dveg==",
          },
          {
            id: "hero-mujtaba-8",
            title: "المحتوى الثامن",
            url: "https://www.instagram.com/reel/DWwfmMFDWid/?igsi=MTJydjJoNGEzbGozcA==",
          },
          {
            id: "hero-mujtaba-9",
            title: "المحتوى التاسع",
            url: "https://www.instagram.com/reel/DVHMCXyDUJh/?igsi=YW1xM2g4d3I4ZGs2",
          },
          {
            id: "hero-mujtaba-10",
            title: "المحتوى العاشر",
            url: "https://www.instagram.com/reel/DVl08QnDU_x/?igsi=MTJiN2poaXQzb3JtMg==",
          },
          {
            id: "hero-mujtaba-11",
            title: "المحتوى الحادي عشر",
            url: "https://www.instagram.com/reel/DWeiIA0DXev/?igsi=MXBobXI3bHg5b3ZwMg==",
          },
        ],
      },
      {
        id: "hero-mahdi",
        title: "محتوى م.مهدي واثق",
        children: [
          {
            id: "hero-mahdi-bio",
            title: "نبذة عن مهندس مهدي واثق",
            note: "",
          },
          {
            id: "hero-mahdi-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DVT9tVkDYzy/?igsi=MXRxdDh0ZGF6aTloYw==",
          },
          {
            id: "hero-mahdi-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DWmFdSvjT_c/?igsi=djdxdW5vcGt1ZG1u",
          },
          {
            id: "hero-mahdi-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DZnWK2StxvV/?igsi=MXF3bWcyeHY4a2dhdg==",
          },
        ],
      },
      {
        id: "hero-sara",
        title: "محتوى م.سارة محمد",
        children: [
          {
            id: "hero-sara-bio",
            title: "نبذة عن مهندسة سارة محمد",
            note: "",
          },
          {
            id: "hero-sara-1",
            title: "المحتوى الأول",
            url: "https://www.instagram.com/reel/DaTB1ymodrf/?igsi=MTFtNzB6c2Yyeml0Zg==",
          },
          {
            id: "hero-sara-2",
            title: "المحتوى الثاني",
            url: "https://www.instagram.com/reel/DZvBAZQIlTl/?igsi=dzVkMmUxaTZoNnBt",
          },
          {
            id: "hero-sara-3",
            title: "المحتوى الثالث",
            url: "https://www.instagram.com/reel/DZIU9eFITuY/?igsi=MXpldm83bHJkYmJn",
          },
          {
            id: "hero-sara-4",
            title: "المحتوى الرابع",
            url: "https://www.instagram.com/reel/DY-AM_VoW4h/?igsi=dDBzNWs0cmh3dWdk",
          },
          {
            id: "hero-sara-5",
            title: "المحتوى الخامس",
            url: "https://www.instagram.com/reel/DY4_sY-oofK/?igsi=bXN1NW5zcHV1OTJo",
          },
          {
            id: "hero-sara-6",
            title: "المحتوى السادس",
            url: "https://www.instagram.com/reel/DYcoqy4oWhf/?igsi=aGF3dHFrNjBnbmlx",
          },
          {
            id: "hero-sara-7",
            title: "المحتوى السابع",
            url: "https://www.instagram.com/p/DYSUh2aCHXc/?img_index=1&igsi=MWttMXVrMHlrYWZpaQ==",
          },
          {
            id: "hero-sara-8",
            title: "المحتوى الثامن",
            url: "https://www.instagram.com/reel/DX94erVOY0Q/?igsi=MW8zcXN2eTJvYzF5bQ==",
          },
          {
            id: "hero-sara-9",
            title: "المحتوى التاسع",
            url: "https://www.instagram.com/p/DXr6BLCDnok/?igsi=a3YwZ3o2bWd5bmV3",
          },
          {
            id: "hero-sara-10",
            title: "المحتوى العاشر",
            url: "https://www.instagram.com/reel/DXCkXfIja0L/?igsi=YWNxYmFwOHo1YW12",
          },
          {
            id: "hero-sara-11",
            title: "المحتوى الحادي عشر",
            url: "https://www.instagram.com/reel/DWO2YJMDYHP/?igsi=MXBoaDRxZXlldzJwdQ==",
          },
        ],
      },
    ],
  },
];

const EMPTY_WORKSHOP_FORM = {
  title: "",
  category: "",
  description: "",
  imageUrl: "",
  date: "",
  place: "",
  link: "",
  platform: "telegram",
  status: "active",
  price: "",
  paymentLink: "",
  paymentQrImage: "",
};

const EMPTY_LINK_FORM = { title: "", url: "", platform: "telegram" };

const EMPTY_NODE_FORM = { title: "", url: "", note: "", pendingLabel: "", kind: "link" };

function getKids(node) {
  return node.children || node.lessons || [];
}
function withKids(node, kids) {
  const { lessons, children, ...rest } = node;
  return { ...rest, children: kids };
}
function updateTree(list, id, updater) {
  return list.map((node) => {
    if (node.id === id) return updater(node);
    const kids = getKids(node);
    if (kids.length) {
      const newKids = updateTree(kids, id, updater);
      if (newKids !== kids) return withKids(node, newKids);
    }
    return node;
  });
}
function deleteFromTree(list, id) {
  return list
    .filter((node) => node.id !== id)
    .map((node) => {
      const kids = getKids(node);
      if (kids.length) return withKids(node, deleteFromTree(kids, id));
      return node;
    });
}
function addChildToTree(list, parentId, newNode) {
  if (parentId === null) return [...list, newNode];
  return list.map((node) => {
    if (node.id === parentId) {
      return withKids(node, [...getKids(node), newNode]);
    }
    const kids = getKids(node);
    if (kids.length) return withKids(node, addChildToTree(kids, parentId, newNode));
    return node;
  });
}
function buildNodeFromForm(form, existingNode) {
  const base = existingNode ? { ...existingNode } : { id: "n" + Date.now() + Math.floor(Math.random() * 1000) };
  delete base.url;
  delete base.note;
  delete base.pendingLabel;
  if (form.kind === "link") return { ...base, title: form.title, url: form.url };
  if (form.kind === "note") return { ...base, title: form.title, note: form.note };
  if (form.kind === "pending") return { ...base, title: form.title, ...(form.pendingLabel ? { pendingLabel: form.pendingLabel } : {}) };
  // group
  return { ...base, title: form.title, children: (existingNode && getKids(existingNode)) || [] };
}

function moveInList(list, id, dir) {
  const idx = list.findIndex((x) => x.id === id);
  if (idx === -1) return list;
  const newIdx = idx + dir;
  if (newIdx < 0 || newIdx >= list.length) return list;
  const copy = [...list];
  [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
  return copy;
}
function moveInTree(list, id, dir) {
  const idx = list.findIndex((n) => n.id === id);
  if (idx !== -1) {
    const newIdx = idx + dir;
    if (newIdx < 0 || newIdx >= list.length) return list;
    const copy = [...list];
    [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
    return copy;
  }
  return list.map((node) => {
    const kids = getKids(node);
    if (kids.length) {
      const newKids = moveInTree(kids, id, dir);
      if (newKids !== kids) return withKids(node, newKids);
    }
    return node;
  });
}

function useGoogleFonts() {
  useEffect(() => {
    const id = "workshop-site-fonts";
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=El+Messiri:wght@500;600;700&family=Tajawal:wght@400;500;700&family=IBM+Plex+Mono:wght@400;500&display=swap";
    document.head.appendChild(link);
  }, []);
}

const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAACoB4_aRAKlX6b0I9cEpm75q5cjpxQ6Q",
  authDomain: "haedore.firebaseapp.com",
  projectId: "haedore",
  storageBucket: "haedore.firebasestorage.app",
  messagingSenderId: "441052120983",
  appId: "1:441052120983:web:5f093d051914407d7d66d2",
  measurementId: "G-22VKH627F1",
};

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${src}"]`)) {
      resolve();
      return;
    }
    const s = document.createElement("script");
    s.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("failed to load " + src));
    document.head.appendChild(s);
  });
}

let firebaseReadyPromise = null;
function getFirestore() {
  if (!firebaseReadyPromise) {
    firebaseReadyPromise = (async () => {
      await loadScript("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js");
      await loadScript("https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js");
      if (!window.firebase.apps || !window.firebase.apps.length) {
        window.firebase.initializeApp(FIREBASE_CONFIG);
      }
      return window.firebase.firestore();
    })();
  }
  return firebaseReadyPromise;
}

const DOC_MAP = {
  workshops: { collection: "nabd", doc: "workshopsV3", seed: SEED_WORKSHOPS },
  social: { collection: "nabd", doc: "socialLinks", seed: SEED_SOCIAL },
  content: { collection: "nabd", doc: "contentLinks", seed: SEED_CONTENT },
};

async function fbGetItems(type) {
  const db = await getFirestore();
  const ref = db.collection(DOC_MAP[type].collection).doc(DOC_MAP[type].doc);
  const snap = await ref.get();
  if (snap.exists && Array.isArray(snap.data().items)) {
    return snap.data().items;
  }
  await ref.set({ items: DOC_MAP[type].seed });
  return DOC_MAP[type].seed;
}

async function fbSetItems(type, items) {
  const db = await getFirestore();
  const ref = db.collection(DOC_MAP[type].collection).doc(DOC_MAP[type].doc);
  await ref.set({ items });
}

export default function WorkshopSite() {
  useGoogleFonts();

  const [workshops, setWorkshops] = useState([]);
  const [socialLinks, setSocialLinks] = useState([]);
  const [contentLinks, setContentLinks] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [connectionError, setConnectionError] = useState("");

  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [loginError, setLoginError] = useState("");

  const [workshopFormOpen, setWorkshopFormOpen] = useState(false);
  const [workshopEditId, setWorkshopEditId] = useState(null);
  const [workshopForm, setWorkshopForm] = useState(EMPTY_WORKSHOP_FORM);

  const [linkFormOpen, setLinkFormOpen] = useState(false);
  const [linkFormType, setLinkFormType] = useState("social");
  const [linkEditId, setLinkEditId] = useState(null);
  const [linkForm, setLinkForm] = useState(EMPTY_LINK_FORM);

  const [saveError, setSaveError] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [view, setView] = useState("home");

  const loadAll = useCallback(async () => {
    try {
      const [w, s, c] = await Promise.all([
        fbGetItems("workshops"),
        fbGetItems("social"),
        fbGetItems("content"),
      ]);
      setWorkshops(w);
      setSocialLinks(s);
      setContentLinks(c);
    } catch (e) {
      setConnectionError((e && (e.message || e.code)) || String(e) || "خطأ غير معروف");
      setWorkshops(SEED_WORKSHOPS);
      setSocialLinks(SEED_SOCIAL);
      setContentLinks(SEED_CONTENT);
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const persistWorkshops = async (next) => {
    setWorkshops(next);
    try {
      await fbSetItems("workshops", next);
    } catch (e) {
      setSaveError("تعذر حفظ التعديل، تأكد من اتصالك بالإنترنت وحاول مرة أخرى.");
    }
  };

  const persistLinks = async (type, next) => {
    if (type === "social") setSocialLinks(next);
    else setContentLinks(next);
    try {
      await fbSetItems(type, next);
    } catch (e) {
      setSaveError("تعذر حفظ التعديل، تأكد من اتصالك بالإنترنت وحاول مرة أخرى.");
    }
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setShowLogin(false);
      setPasswordInput("");
      setLoginError("");
    } else {
      setLoginError("كلمة السر غير صحيحة");
    }
  };

  // Workshop form handlers
  const openAddWorkshop = () => {
    setWorkshopForm(EMPTY_WORKSHOP_FORM);
    setWorkshopEditId(null);
    setWorkshopFormOpen(true);
  };
  const openEditWorkshop = (w) => {
    setWorkshopForm({
      title: w.title,
      category: w.category,
      description: w.description,
      imageUrl: w.imageUrl,
      date: w.date,
      place: w.place,
      link: w.link,
      platform: w.platform,
      status: w.status || "active",
      price: w.price || "",
      paymentLink: w.paymentLink || "",
      paymentQrImage: w.paymentQrImage || "",
    });
    setWorkshopEditId(w.id);
    setWorkshopFormOpen(true);
  };
  const submitWorkshop = async (e) => {
    e.preventDefault();
    if (!workshopForm.title.trim() || !workshopForm.link.trim()) {
      setSaveError("العنوان والرابط مطلوبان");
      return;
    }
    setSaveError("");
    let next;
    if (workshopEditId) {
      next = workshops.map((w) => (w.id === workshopEditId ? { ...w, ...workshopForm } : w));
    } else {
      next = [...workshops, { ...workshopForm, id: "w" + Date.now() }];
    }
    await persistWorkshops(next);
    setWorkshopFormOpen(false);
    setWorkshopForm(EMPTY_WORKSHOP_FORM);
    setWorkshopEditId(null);
  };
  const deleteWorkshop = async (id) => {
    await persistWorkshops(workshops.filter((w) => w.id !== id));
    setConfirmDelete(null);
  };
  const moveWorkshop = async (id, dir) => {
    await persistWorkshops(moveInList(workshops, id, dir));
  };

  // Link form handlers (social / content)
  const openAddLink = (type) => {
    setLinkFormType(type);
    setLinkForm(EMPTY_LINK_FORM);
    setLinkEditId(null);
    setLinkFormOpen(true);
  };
  const openEditLink = (type, item) => {
    setLinkFormType(type);
    setLinkForm({ title: item.title, url: item.url, platform: item.platform });
    setLinkEditId(item.id);
    setLinkFormOpen(true);
  };
  const submitLink = async (e) => {
    e.preventDefault();
    if (!linkForm.title.trim() || !linkForm.url.trim()) {
      setSaveError("العنوان والرابط مطلوبان");
      return;
    }
    setSaveError("");
    const list = linkFormType === "social" ? socialLinks : contentLinks;
    let next;
    if (linkEditId) {
      next = list.map((item) => (item.id === linkEditId ? { ...item, ...linkForm } : item));
    } else {
      next = [...list, { ...linkForm, id: "l" + Date.now() }];
    }
    await persistLinks(linkFormType, next);
    setLinkFormOpen(false);
    setLinkForm(EMPTY_LINK_FORM);
    setLinkEditId(null);
  };
  const deleteLink = async (type, id) => {
    const list = type === "social" ? socialLinks : contentLinks;
    await persistLinks(type, list.filter((item) => item.id !== id));
    setConfirmDelete(null);
  };
  const moveSocialLink = async (id, dir) => {
    await persistLinks("social", moveInList(socialLinks, id, dir));
  };

  // Generalized node editor (content tree: series / groups / notes / pending / links, any depth)
  const [nodeEditorOpen, setNodeEditorOpen] = useState(false);
  const [nodeEditorMode, setNodeEditorMode] = useState("addRoot"); // 'addRoot' | 'addChild' | 'edit'
  const [nodeEditorTargetId, setNodeEditorTargetId] = useState(null);
  const [nodeEditorParentId, setNodeEditorParentId] = useState(null);
  const [nodeEditorForm, setNodeEditorForm] = useState(EMPTY_NODE_FORM);

  const openNodeEditor = (mode, targetId = null, parentId = null, existingNode = null) => {
    setNodeEditorMode(mode);
    setNodeEditorTargetId(targetId);
    setNodeEditorParentId(parentId);
    if (existingNode) {
      const kind = existingNode.children || existingNode.lessons
        ? "group"
        : typeof existingNode.note === "string"
        ? "note"
        : existingNode.url
        ? "link"
        : "pending";
      setNodeEditorForm({
        title: existingNode.title || "",
        url: existingNode.url || "",
        note: existingNode.note || "",
        pendingLabel: existingNode.pendingLabel || "",
        kind,
      });
    } else {
      setNodeEditorForm(EMPTY_NODE_FORM);
    }
    setNodeEditorOpen(true);
  };

  const submitNodeEditor = async (e) => {
    e.preventDefault();
    if (!nodeEditorForm.title.trim()) {
      setSaveError("العنوان مطلوب");
      return;
    }
    if (nodeEditorForm.kind === "link" && !nodeEditorForm.url.trim()) {
      setSaveError("الرابط مطلوب لهذا النوع");
      return;
    }
    setSaveError("");
    let next;
    if (nodeEditorMode === "edit") {
      next = updateTree(contentLinks, nodeEditorTargetId, (old) => buildNodeFromForm(nodeEditorForm, old));
    } else {
      const newNode = buildNodeFromForm(nodeEditorForm, null);
      next = addChildToTree(contentLinks, nodeEditorMode === "addChild" ? nodeEditorParentId : null, newNode);
    }
    await persistLinks("content", next);
    setNodeEditorOpen(false);
    setNodeEditorForm(EMPTY_NODE_FORM);
  };

  const deleteContentNode = async (id) => {
    await persistLinks("content", deleteFromTree(contentLinks, id));
  };
  const moveContentNode = async (id, dir) => {
    await persistLinks("content", moveInTree(contentLinks, id, dir));
  };

  return (
    <div
      dir="rtl"
      style={{ fontFamily: "'Tajawal', sans-serif", backgroundColor: "#FFFFFF" }}
      className="min-h-screen text-[#1F2430]"
    >
      {/* Header */}
      <header className="border-b border-[#E4E1D8] sticky top-0 z-30 backdrop-blur-sm bg-[#FFFFFFee]">
        <div className="max-w-5xl mx-auto px-5 py-4 flex items-center justify-between">
          {view === "home" ? (
            <div className="flex items-center gap-2">
              <img src={LOGO_SRC} alt="نَبض" className="w-9 h-9 rounded-full object-cover" />
              <span
                style={{ fontFamily: "'El Messiri', serif" }}
                className="text-lg font-semibold tracking-tight"
              >
                منصة نَبض
              </span>
            </div>
          ) : (
            <button
              onClick={() => setView("home")}
              className="flex items-center gap-1.5 text-sm text-[#4B5563] hover:text-[#1F2430]"
            >
              <ArrowRight size={18} />
              الرئيسية
            </button>
          )}
          <button
            onClick={() => (isAdmin ? setIsAdmin(false) : setShowLogin(true))}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-full border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D] transition-colors"
          >
            <Lock size={13} />
            {isAdmin ? "تسجيل الخروج" : "دخول المشرف"}
          </button>
        </div>
      </header>

      {connectionError && (
        <div
          className="text-center text-xs py-2 px-4"
          style={{ backgroundColor: "#FBEFE7", color: "#9A5A22" }}
        >
          تعذر الاتصال بقاعدة البيانات — البيانات المعروضة محلية مؤقتًا ولن تُحفظ.
          <br />
          <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: "10px" }}>
            تفاصيل الخطأ: {connectionError}
          </span>
        </div>
      )}

      {view === "home" && (
      <>
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-5 pt-12 pb-8 flex flex-col items-center text-center">
        <img
          src={LOGO_SRC}
          alt="Pulse Biomedical Engineering"
          className="w-40 h-40 sm:w-48 sm:h-48 object-contain mb-6"
        />
        <h1
          style={{ fontFamily: "'El Messiri', serif" }}
          className="text-3xl sm:text-4xl font-bold leading-tight"
        >
          نبذة عن منصة نَبُض
        </h1>
        <div
          className="mt-5 max-w-2xl text-[#4B5563] leading-loose text-sm sm:text-base text-right"
          dir="rtl"
        >
          <p className="mb-3">
            منصة طلابية تعليمية تهدف إلى توسعة المعرفة والتطوير العلمي والمهني وجعلك مهندسًا محترفًا في مجال هندسة الطب الحياتي، وتشرح جميع اختصاصات هندسة الطب الحياتي، من ضمنها: الأجهزة وصيانتها، الأطراف الصناعية، الذكاء الاصطناعي، البرمجة، هندسة الأنسجة، والهندسة الوراثية والعصبية وغيرها.
          </p>
          <p className="mb-3">
            وأيضًا قائمة على مؤتمرات وورش ودورات تدريبية، منها المجاني ومنها المدفوع، وبالتأكيد الورش المجانية تكون أكثر من المدفوعة.
          </p>
          <p>وأيضًا عمل CV يليق بك، وشرح المناهج الدراسية.</p>
        </div>

        {/* Three nav buttons */}
        <div className="flex flex-wrap justify-center gap-3 mt-8">
          <button
            onClick={() => setView("social")}
            className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-transform hover:-translate-y-0.5"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #D9D4C6" }}
          >
            <Users size={16} style={{ color: "#E8A33D" }} />
            حساباتنا على مواقع التواصل الاجتماعي
          </button>
          <button
            onClick={() => setView("workshops")}
            className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-transform hover:-translate-y-0.5"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #D9D4C6" }}
          >
            <BookOpen size={16} style={{ color: "#E8A33D" }} />
            ورشنا ودوراتنا التدريبية
          </button>
          <button
            onClick={() => setView("content")}
            className="flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-transform hover:-translate-y-0.5"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #D9D4C6" }}
          >
            <Layers size={16} style={{ color: "#E8A33D" }} />
            محتوياتنا
          </button>
        </div>
      </section>
      </>
      )}

      {/* Social links section */}
      {view === "social" && (
      <LinkSection
        id="social"
        title="حساباتنا على مواقع التواصل الاجتماعي"
        items={socialLinks}
        type="social"
        isAdmin={isAdmin}
        onAdd={() => openAddLink("social")}
        onEdit={(item) => openEditLink("social", item)}
        onDelete={(id) => setConfirmDelete({ type: "social", id })}
        onMove={(id, dir) => moveSocialLink(id, dir)}
        confirmDelete={confirmDelete}
        onConfirmDelete={(id) => deleteLink("social", id)}
        onCancelDelete={() => setConfirmDelete(null)}
      />
      )}

      {/* Workshops section */}
      {view === "workshops" && (
      <section id="workshops" className="max-w-5xl mx-auto px-5 pb-4 pt-10 scroll-mt-20">
        <div className="flex items-center justify-between mb-5">
          <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-xl font-semibold">
            ورشنا ودوراتنا التدريبية
          </h2>
          {isAdmin && (
            <button
              onClick={openAddWorkshop}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg font-medium"
              style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
            >
              <Plus size={14} />
              إضافة ورشة
            </button>
          )}
        </div>

        {!loaded ? (
          <p className="text-[#6B7280] text-sm">جاري التحميل...</p>
        ) : workshops.length === 0 ? (
          <div className="border border-dashed border-[#D9D4C6] rounded-xl p-10 text-center text-[#6B7280]">
            لا توجد ورشات بعد.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {workshops.map((w) => {
              const meta = PLATFORM_META[w.platform] || PLATFORM_META.other;
              const Icon = meta.icon;
              return (
                <div
                  key={w.id}
                  className="relative rounded-xl overflow-hidden flex"
                  style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
                >
                  <div
                    className="w-8 flex items-center justify-center shrink-0"
                    style={{
                      borderLeft: "2px dashed #D9D4C6",
                      background:
                        "repeating-linear-gradient(180deg, transparent, transparent 6px, #F8F7F2 6px, #F8F7F2 7px)",
                    }}
                  >
                    <span
                      style={{
                        writingMode: "vertical-rl",
                        fontFamily: "'IBM Plex Mono', monospace",
                        color: "#6B7280",
                        letterSpacing: "0.1em",
                      }}
                      className="text-[10px] py-2"
                    >
                      {w.category || "ورشة"}
                    </span>
                  </div>

                  <div className="flex-1 flex flex-col">
                    {w.imageUrl && (
                      <div className="relative w-full aspect-square overflow-hidden bg-white">
                        <img
                          src={w.imageUrl}
                          alt={w.title}
                          className="w-full h-full object-contain"
                          onError={(e) => (e.target.style.display = "none")}
                        />
                        {w.status === "ended" && (
                          <div
                            className="absolute top-3 left-3 px-3 py-1 rounded-full text-[11px] font-bold"
                            style={{ backgroundColor: "#C1502E", color: "#FAF7F0" }}
                          >
                            انتهت
                          </div>
                        )}
                      </div>
                    )}
                    <div className="p-4 flex-1 flex flex-col">
                      <h3
                        style={{ fontFamily: "'El Messiri', serif" }}
                        className="text-base font-semibold leading-snug mb-1.5"
                      >
                        {w.title}
                      </h3>
                      <p
                        className="text-xs text-[#6B7280] leading-relaxed mb-3 flex-1"
                        style={{ whiteSpace: "pre-line" }}
                      >
                        {w.description}
                      </p>

                      {(w.date || w.place) && (
                        <div
                          style={{ fontFamily: "'IBM Plex Mono', monospace" }}
                          className="flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-[#6B7280] mb-3"
                        >
                          {w.date && <span>📅 {w.date}</span>}
                          {w.place && <span>📍 {w.place}</span>}
                        </div>
                      )}

                      {w.status !== "ended" && (w.price || w.paymentLink || w.paymentQrImage) && (
                        <div
                          className="rounded-lg p-3 mb-3 flex flex-col gap-2"
                          style={{ backgroundColor: "#FBF6E9", border: "1px solid #F0E3BE" }}
                        >
                          {w.price && (
                            <div
                              style={{ fontFamily: "'IBM Plex Mono', monospace" }}
                              className="text-xs font-medium text-[#9A6B22]"
                            >
                              💳 السعر: {w.price}
                            </div>
                          )}
                          {w.paymentLink && (
                            <a
                              href={w.paymentLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center justify-center gap-1.5 text-xs font-medium py-2 rounded-md"
                              style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
                            >
                              ادفع الآن
                              <ArrowUpRight size={12} />
                            </a>
                          )}
                          {w.paymentQrImage && (
                            <img
                              src={w.paymentQrImage}
                              alt="رمز الدفع QR"
                              className="w-28 h-28 object-contain mx-auto rounded-md bg-white p-1"
                              style={{ border: "1px solid #F0E3BE" }}
                            />
                          )}
                        </div>
                      )}

                      {w.status === "ended" ? (
                        <div
                          className="flex items-center justify-center gap-1.5 text-sm font-medium py-2.5 rounded-lg"
                          style={{ backgroundColor: "#EDEAE0", color: "#6B7280" }}
                        >
                          انتهت الدورة — التسجيل مغلق
                        </div>
                      ) : (
                        <a
                          href={w.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="group flex items-center justify-center gap-1.5 text-sm font-medium py-2.5 rounded-lg transition-colors"
                          style={{ backgroundColor: meta.color, color: "#FAF7F0" }}
                        >
                          <Icon size={14} />
                          انضم الآن عبر {meta.label}
                          <ArrowUpRight size={14} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                        </a>
                      )}

                      {isAdmin && (
                        <div className="flex gap-2 mt-2.5">
                          <button
                            onClick={() => moveWorkshop(w.id, -1)}
                            title="تحريك لأعلى"
                            className="w-8 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                          >
                            <ChevronUp size={13} />
                          </button>
                          <button
                            onClick={() => moveWorkshop(w.id, 1)}
                            title="تحريك لأسفل"
                            className="w-8 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                          >
                            <ChevronDown size={13} />
                          </button>
                          <button
                            onClick={() => openEditWorkshop(w)}
                            className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                          >
                            <Pencil size={11} /> تعديل
                          </button>
                          {confirmDelete && confirmDelete.type === "workshop" && confirmDelete.id === w.id ? (
                            <button
                              onClick={() => deleteWorkshop(w.id)}
                              className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md font-medium"
                              style={{ backgroundColor: "#C1502E", color: "#FAF7F0" }}
                            >
                              تأكيد الحذف؟
                            </button>
                          ) : (
                            <button
                              onClick={() => setConfirmDelete({ type: "workshop", id: w.id })}
                              className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#C1502E] hover:border-[#C1502E]"
                            >
                              <Trash2 size={11} /> حذف
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
      )}

      {/* Content links section */}
      {view === "content" && (
      <LinkSection
        id="content"
        title="محتوياتنا"
        items={contentLinks}
        type="content"
        isAdmin={isAdmin}
        onAddRoot={() => openNodeEditor("addRoot")}
        onNodeEdit={(node) => openNodeEditor("edit", node.id, null, node)}
        onNodeAddChild={(parentId) => openNodeEditor("addChild", null, parentId)}
        onNodeDelete={(id) => deleteContentNode(id)}
        onNodeMove={(id, dir) => moveContentNode(id, dir)}
      />
      )}

      {/* Login modal */}
      {showLogin && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-5">
          <div
            className="w-full max-w-sm rounded-xl p-6"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-lg font-semibold">
                دخول المشرف
              </h2>
              <button onClick={() => setShowLogin(false)} className="text-[#6B7280] hover:text-[#1F2430]">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={handleLogin}>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="كلمة السر"
                autoFocus
                className="w-full px-3 py-2.5 rounded-lg text-sm mb-2 outline-none"
                style={{ backgroundColor: "#FFFFFF", border: "1px solid #D9D4C6", color: "#1F2430" }}
              />
              {loginError && <p className="text-[#C1502E] text-xs mb-2">{loginError}</p>}
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg text-sm font-medium mt-2"
                style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
              >
                دخول
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add/Edit workshop modal */}
      {workshopFormOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-5 py-8 overflow-y-auto">
          <div
            className="w-full max-w-md rounded-xl p-6"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-lg font-semibold">
                {workshopEditId ? "تعديل الورشة" : "إضافة ورشة"}
              </h2>
              <button onClick={() => setWorkshopFormOpen(false)} className="text-[#6B7280] hover:text-[#1F2430]">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitWorkshop} className="space-y-3">
              <Field label="عنوان الورشة *">
                <input
                  value={workshopForm.title}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, title: e.target.value })}
                  style={inputStyle}
                />
              </Field>
              <Field label="التصنيف (مثال: تصميم، برمجة)">
                <input
                  value={workshopForm.category}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, category: e.target.value })}
                  style={inputStyle}
                />
              </Field>
              <Field label="الوصف">
                <textarea
                  value={workshopForm.description}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, description: e.target.value })}
                  rows={3}
                  style={inputStyle}
                />
              </Field>
              <Field label="رابط الصورة">
                <input
                  value={workshopForm.imageUrl}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, imageUrl: e.target.value })}
                  placeholder="https://..."
                  style={inputStyle}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="الموعد">
                  <input
                    value={workshopForm.date}
                    onChange={(e) => setWorkshopForm({ ...workshopForm, date: e.target.value })}
                    style={inputStyle}
                  />
                </Field>
                <Field label="المكان">
                  <input
                    value={workshopForm.place}
                    onChange={(e) => setWorkshopForm({ ...workshopForm, place: e.target.value })}
                    style={inputStyle}
                  />
                </Field>
              </div>
              <Field label="المنصة">
                <select
                  value={workshopForm.platform}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, platform: e.target.value })}
                  style={inputStyle}
                >
                  {Object.entries(PLATFORM_META).map(([key, m]) => (
                    <option key={key} value={key}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="رابط الانضمام *">
                <input
                  value={workshopForm.link}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, link: e.target.value })}
                  placeholder="https://t.me/..."
                  style={inputStyle}
                />
              </Field>
              <Field label="حالة الورشة">
                <select
                  value={workshopForm.status}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, status: e.target.value })}
                  style={inputStyle}
                >
                  <option value="active">نشطة (التسجيل مفتوح)</option>
                  <option value="ended">انتهت (التسجيل مغلق)</option>
                </select>
              </Field>
              <Field label="السعر (اتركه فاضي إذا الورشة مجانية)">
                <input
                  value={workshopForm.price}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, price: e.target.value })}
                  placeholder="مثال: 25,000 د.ع"
                  style={inputStyle}
                />
              </Field>
              <Field label="رابط الدفع (K Card / FIB / Zain Cash...) — اختياري">
                <input
                  value={workshopForm.paymentLink}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, paymentLink: e.target.value })}
                  placeholder="https://..."
                  style={inputStyle}
                />
              </Field>
              <Field label="رابط صورة رمز الدفع QR — اختياري">
                <input
                  value={workshopForm.paymentQrImage}
                  onChange={(e) => setWorkshopForm({ ...workshopForm, paymentQrImage: e.target.value })}
                  placeholder="https://..."
                  style={inputStyle}
                />
              </Field>

              {saveError && <p className="text-[#C1502E] text-xs">{saveError}</p>}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium mt-2"
                style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
              >
                <Check size={15} />
                {workshopEditId ? "حفظ التعديل" : "إضافة الورشة"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add/Edit link modal (social / content) */}
      {linkFormOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-5 py-8 overflow-y-auto">
          <div
            className="w-full max-w-md rounded-xl p-6"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-lg font-semibold">
                {linkEditId ? "تعديل الرابط" : "إضافة رابط"}
              </h2>
              <button onClick={() => setLinkFormOpen(false)} className="text-[#6B7280] hover:text-[#1F2430]">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitLink} className="space-y-3">
              <Field label="العنوان *">
                <input
                  value={linkForm.title}
                  onChange={(e) => setLinkForm({ ...linkForm, title: e.target.value })}
                  style={inputStyle}
                />
              </Field>
              <Field label="المنصة">
                <select
                  value={linkForm.platform}
                  onChange={(e) => setLinkForm({ ...linkForm, platform: e.target.value })}
                  style={inputStyle}
                >
                  {Object.entries(PLATFORM_META).map(([key, m]) => (
                    <option key={key} value={key}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="الرابط *">
                <input
                  value={linkForm.url}
                  onChange={(e) => setLinkForm({ ...linkForm, url: e.target.value })}
                  placeholder="https://..."
                  style={inputStyle}
                />
              </Field>

              {saveError && <p className="text-[#C1502E] text-xs">{saveError}</p>}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium mt-2"
                style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
              >
                <Check size={15} />
                {linkEditId ? "حفظ التعديل" : "إضافة الرابط"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Generalized content node editor (series / groups / notes / pending / links, any depth) */}
      {nodeEditorOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-5 py-8 overflow-y-auto">
          <div
            className="w-full max-w-md rounded-xl p-6"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-lg font-semibold">
                {nodeEditorMode === "edit" ? "تعديل عنصر" : "إضافة عنصر"}
              </h2>
              <button onClick={() => setNodeEditorOpen(false)} className="text-[#6B7280] hover:text-[#1F2430]">
                <X size={18} />
              </button>
            </div>
            <form onSubmit={submitNodeEditor} className="space-y-3">
              <Field label="نوع العنصر">
                <select
                  value={nodeEditorForm.kind}
                  onChange={(e) => setNodeEditorForm({ ...nodeEditorForm, kind: e.target.value })}
                  style={inputStyle}
                >
                  <option value="link">رابط مباشر</option>
                  <option value="group">مجموعة (تحتوي عناصر فرعية)</option>
                  <option value="note">نبذة نصية</option>
                  <option value="pending">قريبًا (بدون رابط)</option>
                </select>
              </Field>
              <Field label="العنوان *">
                <input
                  value={nodeEditorForm.title}
                  onChange={(e) => setNodeEditorForm({ ...nodeEditorForm, title: e.target.value })}
                  style={inputStyle}
                />
              </Field>
              {nodeEditorForm.kind === "link" && (
                <Field label="الرابط *">
                  <input
                    value={nodeEditorForm.url}
                    onChange={(e) => setNodeEditorForm({ ...nodeEditorForm, url: e.target.value })}
                    placeholder="https://..."
                    style={inputStyle}
                  />
                </Field>
              )}
              {nodeEditorForm.kind === "note" && (
                <Field label="النص">
                  <textarea
                    value={nodeEditorForm.note}
                    onChange={(e) => setNodeEditorForm({ ...nodeEditorForm, note: e.target.value })}
                    rows={5}
                    style={inputStyle}
                  />
                </Field>
              )}
              {nodeEditorForm.kind === "pending" && (
                <Field label="ملاحظة (اختياري، مثال: سيُضاف يوم الخميس)">
                  <input
                    value={nodeEditorForm.pendingLabel}
                    onChange={(e) => setNodeEditorForm({ ...nodeEditorForm, pendingLabel: e.target.value })}
                    placeholder="قريبًا"
                    style={inputStyle}
                  />
                </Field>
              )}
              {nodeEditorForm.kind === "group" && (
                <p className="text-xs text-[#6B7280]">
                  بعد الحفظ، تقدر تضيف عناصر فرعية داخل هذه المجموعة بالضغط على زر "+" جنبها.
                </p>
              )}

              {saveError && <p className="text-[#C1502E] text-xs">{saveError}</p>}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium mt-2"
                style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
              >
                <Check size={15} />
                {nodeEditorMode === "edit" ? "حفظ التعديل" : "إضافة"}
              </button>
            </form>
          </div>
        </div>
      )}

      <footer className="border-t border-[#E4E1D8] py-6 text-center text-[10px] text-[#9CA3AF]">
        <span style={{ fontFamily: "'IBM Plex Mono', monospace" }}>منصة نَبض — {new Date().getFullYear()}</span>
      </footer>
    </div>
  );
}

function LinkSection({
  id,
  title,
  items,
  type,
  isAdmin,
  onAdd,
  onEdit,
  onDelete,
  onMove,
  confirmDelete,
  onConfirmDelete,
  onCancelDelete,
  onAddRoot,
  onNodeEdit,
  onNodeAddChild,
  onNodeDelete,
  onNodeMove,
}) {
  if (type === "content") {
    return (
      <section id={id} className="max-w-5xl mx-auto px-5 pb-4 pt-10 scroll-mt-20">
        <div className="flex items-center justify-between mb-5">
          <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-xl font-semibold">
            {title}
          </h2>
          {isAdmin && (
            <button
              onClick={onAddRoot}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg font-medium"
              style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
            >
              <Plus size={14} />
              إضافة عنصر
            </button>
          )}
        </div>

        {items.length === 0 ? (
          <div className="border border-dashed border-[#D9D4C6] rounded-xl p-8 text-center text-[#6B7280] text-sm">
            لا يوجد محتوى بعد.
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {items.map((item) => (
              <LessonNode
                key={item.id}
                node={item}
                isAdmin={isAdmin}
                onEdit={onNodeEdit}
                onAddChild={onNodeAddChild}
                onDelete={onNodeDelete}
                onMove={onNodeMove}
                topLevel
              />
            ))}
          </div>
        )}
      </section>
    );
  }

  // Flat list (social)
  return (
    <section id={id} className="max-w-5xl mx-auto px-5 pb-4 pt-10 scroll-mt-20">
      <div className="flex items-center justify-between mb-5">
        <h2 style={{ fontFamily: "'El Messiri', serif" }} className="text-xl font-semibold">
          {title}
        </h2>
        {isAdmin && (
          <button
            onClick={onAdd}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg font-medium"
            style={{ backgroundColor: "#E8A33D", color: "#14181F" }}
          >
            <Plus size={14} />
            إضافة
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className="border border-dashed border-[#D9D4C6] rounded-xl p-8 text-center text-[#6B7280] text-sm">
          لا توجد روابط بعد.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 items-start">
          {items.map((item) => {
            const isConfirming =
              confirmDelete && confirmDelete.type === type && confirmDelete.id === item.id;
            const meta = PLATFORM_META[item.platform] || PLATFORM_META.other;
            const Icon = meta.icon;
            return (
              <div
                key={item.id}
                className="rounded-xl p-4 flex flex-col gap-3"
                style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }}
              >
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-3"
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: meta.color }}
                  >
                    <Icon size={18} color="#FAF7F0" />
                  </div>
                  <span className="text-sm font-medium flex-1">{item.title}</span>
                  <ArrowUpRight
                    size={16}
                    className="text-[#6B7280] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                  />
                </a>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onMove(item.id, -1)}
                      title="تحريك لأعلى"
                      className="w-8 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                    >
                      <ChevronUp size={13} />
                    </button>
                    <button
                      onClick={() => onMove(item.id, 1)}
                      title="تحريك لأسفل"
                      className="w-8 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                    >
                      <ChevronDown size={13} />
                    </button>
                    <button
                      onClick={() => onEdit(item)}
                      className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
                    >
                      <Pencil size={11} /> تعديل
                    </button>
                    {isConfirming ? (
                      <button
                        onClick={() => onConfirmDelete(item.id)}
                        className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md font-medium"
                        style={{ backgroundColor: "#C1502E", color: "#FAF7F0" }}
                      >
                        تأكيد الحذف؟
                      </button>
                    ) : (
                      <button
                        onClick={() => onDelete(item.id)}
                        className="flex-1 flex items-center justify-center gap-1 text-[11px] py-1.5 rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#C1502E] hover:border-[#C1502E]"
                      >
                        <Trash2 size={11} /> حذف
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}

function AdminNodeControls({ isAdmin, canAddChild, onEdit, onAddChild, onDelete, onMoveUp, onMoveDown }) {
  const [confirming, setConfirming] = useState(false);
  if (!isAdmin) return null;
  return (
    <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
      {onMoveUp && (
        <button
          onClick={onMoveUp}
          title="تحريك لأعلى"
          className="w-6 h-6 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
        >
          <ChevronUp size={12} />
        </button>
      )}
      {onMoveDown && (
        <button
          onClick={onMoveDown}
          title="تحريك لأسفل"
          className="w-6 h-6 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
        >
          <ChevronDown size={12} />
        </button>
      )}
      {canAddChild && (
        <button
          onClick={onAddChild}
          title="إضافة عنصر فرعي"
          className="w-6 h-6 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
        >
          <Plus size={12} />
        </button>
      )}
      <button
        onClick={onEdit}
        title="تعديل"
        className="w-6 h-6 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#1F2430] hover:border-[#E8A33D]"
      >
        <Pencil size={12} />
      </button>
      {confirming ? (
        <button
          onClick={onDelete}
          title="تأكيد الحذف"
          className="px-1.5 h-6 flex items-center justify-center rounded-md text-[10px] font-medium"
          style={{ backgroundColor: "#C1502E", color: "#FAF7F0" }}
        >
          تأكيد؟
        </button>
      ) : (
        <button
          onClick={() => setConfirming(true)}
          title="حذف"
          className="w-6 h-6 flex items-center justify-center rounded-md border border-[#D9D4C6] text-[#6B7280] hover:text-[#C1502E] hover:border-[#C1502E]"
        >
          <Trash2 size={12} />
        </button>
      )}
    </div>
  );
}

function LessonNode({ node, isAdmin, onEdit, onAddChild, onDelete, onMove, topLevel }) {
  const [open, setOpen] = useState(false);
  const kids = node.children || node.lessons || [];
  const wrapperClass = topLevel
    ? "rounded-xl p-4"
    : "rounded-lg";
  const wrapperStyle = topLevel
    ? { backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8" }
    : {};

  const moveProps = onMove
    ? { onMoveUp: () => onMove(node.id, -1), onMoveDown: () => onMove(node.id, 1) }
    : {};

  if (kids.length > 0) {
    return (
      <div className={topLevel ? wrapperClass : "flex flex-col gap-2"} style={wrapperStyle}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-right flex-1"
            style={topLevel ? {} : { backgroundColor: "#FFFFFF", border: "1px solid #E4E1D8" }}
          >
            {topLevel ? (
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: "#2F6F62" }}
              >
                <Layers size={17} color="#FAF7F0" />
              </div>
            ) : (
              <BookOpen size={15} style={{ color: "#2F6F62" }} />
            )}
            <span className="flex-1 font-medium text-right">{node.title}</span>
            <ChevronDown
              size={14}
              className="text-[#6B7280] transition-transform"
              style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)" }}
            />
          </button>
          <AdminNodeControls
            isAdmin={isAdmin}
            canAddChild
            onEdit={() => onEdit(node)}
            onAddChild={() => onAddChild(node.id)}
            onDelete={() => onDelete(node.id)}
            {...moveProps}
          />
        </div>
        {open && (
          <div className="flex flex-col gap-2 pr-3 mr-1 pt-1 border-r-2" style={{ borderColor: "#E4E1D8" }}>
            {kids.length === 0 ? (
              <p className="text-xs text-[#9CA3AF] px-2">لا توجد عناصر فرعية بعد.</p>
            ) : (
              kids.map((child) => (
                <LessonNode
                  key={child.id}
                  node={child}
                  isAdmin={isAdmin}
                  onEdit={onEdit}
                  onAddChild={onAddChild}
                  onDelete={onDelete}
                  onMove={onMove}
                />
              ))
            )}
          </div>
        )}
      </div>
    );
  }

  const hasNote = typeof node.note === "string" && node.note.trim().length > 0;
  const isPending = !hasNote && !node.url;

  if (hasNote) {
    return (
      <div className={topLevel ? wrapperClass : "flex flex-col gap-2"} style={wrapperStyle}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-right flex-1"
            style={topLevel ? {} : { backgroundColor: "#FFFFFF", border: "1px solid #E4E1D8" }}
          >
            <FileText size={15} style={{ color: "#E8A33D" }} />
            <span className="flex-1 font-medium text-right">{node.title}</span>
            <ChevronDown
              size={14}
              className="text-[#6B7280] transition-transform"
              style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)" }}
            />
          </button>
          <AdminNodeControls
            isAdmin={isAdmin}
            canAddChild={false}
            onEdit={() => onEdit(node)}
            onAddChild={() => {}}
            onDelete={() => onDelete(node.id)}
            {...moveProps}
          />
        </div>
        {open && (
          <div
            className="px-3 py-2.5 rounded-lg text-xs leading-relaxed mr-1"
            style={{ backgroundColor: "#F8F7F2", border: "1px solid #E4E1D8", whiteSpace: "pre-line" }}
          >
            {node.note}
          </div>
        )}
      </div>
    );
  }

  if (isPending) {
    return (
      <div className={topLevel ? wrapperClass : "flex items-center gap-2"} style={wrapperStyle}>
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm flex-1"
          style={topLevel ? {} : { backgroundColor: "#F3F1EA", border: "1px dashed #D9D4C6", color: "#9CA3AF" }}
        >
          <Clock size={15} />
          <span className="flex-1">{node.title}</span>
          <span className="text-[10px]">{node.pendingLabel || "قريبًا"}</span>
        </div>
        <AdminNodeControls
          isAdmin={isAdmin}
          canAddChild={false}
          onEdit={() => onEdit(node)}
          onAddChild={() => {}}
          onDelete={() => onDelete(node.id)}
          {...moveProps}
        />
      </div>
    );
  }

  return (
    <div className={topLevel ? wrapperClass : "flex items-center gap-2"} style={wrapperStyle}>
      <a
        href={node.url}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2 px-3 py-2 rounded-lg text-sm flex-1"
        style={topLevel ? {} : { backgroundColor: "#FFFFFF", border: "1px solid #E4E1D8" }}
      >
        <PlayCircle size={15} style={{ color: "#2F6F62" }} />
        <span className="flex-1">{node.title}</span>
        <ArrowUpRight
          size={14}
          className="text-[#6B7280] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
        />
      </a>
      <AdminNodeControls
        isAdmin={isAdmin}
        canAddChild={false}
        onEdit={() => onEdit(node)}
        onAddChild={() => {}}
        onDelete={() => onDelete(node.id)}
        {...moveProps}
      />
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="block text-xs text-[#6B7280] mb-1">{label}</label>
      {children}
    </div>
  );
}

const inputStyle = {
  width: "100%",
  backgroundColor: "#FFFFFF",
  border: "1px solid #D9D4C6",
  color: "#1F2430",
  borderRadius: "0.5rem",
  padding: "0.55rem 0.75rem",
  fontSize: "0.875rem",
  outline: "none",
};
